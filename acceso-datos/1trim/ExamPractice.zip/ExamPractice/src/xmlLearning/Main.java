package xmlLearning;

public class Main {
    public static void main(String[] args) {
        XMLRepaso xmlr = new XMLRepaso("libros.xml");
        xmlr.transformarXml("almacenes/libros.xml");


    }
}
