package xmlSim;

public class Precipitacion {
    private Lugar lugar;

    public Precipitacion(Lugar lugar) {
        this.lugar = lugar;
    }

    public Lugar getLugar() {
        return lugar;
    }

    public void setLugar(Lugar lugar) {
        this.lugar = lugar;
    }
}
