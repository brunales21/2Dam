package com.example.ventanas;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private Button boton;
    private EditText user, password;
    private TextView migas, textView3;
    private String path = "";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_view);
        boton = findViewById(R.id.button);
        user = findViewById(R.id.usuario);
        password = findViewById(R.id.contrasenia);
        migas = findViewById(R.id.migas1);
        textView3 = findViewById(R.id.textView3);
        path = getClass().getSimpleName();
        migas.setText(path);

        String user = getIntent().getStringExtra("user");
        String pass = getIntent().getStringExtra("pasword");
        this.user.setText(user);
        password.setText(pass);


        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = MainActivity.this.user.getText().toString();
                String password = MainActivity.this.password.getText().toString();
                String consultaSQL = "select user,password from credentials where user='" + user + "';";

                try (DBHandler claseBBDD = new DBHandler(MainActivity.this, "usuarios", null, 1);
                     SQLiteDatabase bbdd = claseBBDD.getWritableDatabase();
                     Cursor ejecucionConsulta = bbdd.rawQuery(consultaSQL, null)) {
                    if (ejecucionConsulta.moveToFirst()) {
                        String contraseniaBBDD = ejecucionConsulta.getString(1);
                        if (contraseniaBBDD.equals(password)) {
                            Intent acceso = new Intent(MainActivity.this, Activity2.class);
                            acceso.putExtra("Migas", MainActivity.this.getLocalClassName());
                            acceso.putExtra("UserName", MainActivity.this.user.getText().toString());

                            MainActivity.this.startActivity(acceso);
                        } else {
                            Toast.makeText(MainActivity.this, "Los datos son incorrectos", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "Los datos son incorrectos", Toast.LENGTH_LONG).show();

                    }
                }


            }
        });

        textView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerPage = new Intent(MainActivity.this, Register.class);
                startActivity(registerPage);
            }
        });
    }


}