package com.example.ventanas;


import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;


public class DBHandler extends SQLiteOpenHelper {

    private static final String NOMBRE_BDD = "usuarios";

    private static final int VERSION_BDD = 1;

    private static final String NOMBRE_TABLA = "credentials";

    private static final String ID_COL = "user";

    private static final String COLUMNA_CONTRASENA = "password";

    public DBHandler(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE IF NOT EXISTS " + NOMBRE_TABLA + " ("
                + ID_COL + " VARCHAR(50) PRIMARY KEY, "
                + COLUMNA_CONTRASENA + " TEXT)";
        db.execSQL(query);
    }


    public void addNewCourse(String user, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ID_COL, user);
        values.put(COLUMNA_CONTRASENA, password);
        db.insert(NOMBRE_TABLA, null, values);
        db.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + NOMBRE_TABLA);
        onCreate(db);
    }


}


