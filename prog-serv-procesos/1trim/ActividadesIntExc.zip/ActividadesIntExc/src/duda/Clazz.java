package duda;

public class Clazz extends Thread {
    @Override
    public void run() {
        System.out.println("hola, vengo de thread");
    }
}
