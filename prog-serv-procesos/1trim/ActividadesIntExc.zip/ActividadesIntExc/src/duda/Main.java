package duda;

public class Main {
    public static void main(String[] args) {
        Clazz c1 = new Clazz();
        c1.start();

        Clazz2 c2 = new Clazz2();
        c2.run();
    }
}
