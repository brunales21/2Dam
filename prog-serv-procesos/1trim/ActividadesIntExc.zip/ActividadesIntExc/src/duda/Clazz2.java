package duda;

public class Clazz2 implements Runnable {
    @Override
    public void run() {
        System.out.println("hola, vengo de runable");
    }
}
