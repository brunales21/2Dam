import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        Alumno a1 = new Alumno("Pele", 8);
        Alumno a2 = new Alumno("Maradona", 10);
        Alumno a3 = new Alumno("Mohamed Ali", 9);
        Alumno a4 = new Alumno("Bruno", 10);
        Alumno a5 = new Alumno("Pepito"); // en este caso no introduzco nota (se queda con un 0)
        Alumno a6 = new Alumno(5); // en este caso no introduzco nombre (por defecto queda como anónimo)

        List<Alumno> alumnos = new ArrayList<>();
        alumnos.add(a1);
        alumnos.add(a2);
        alumnos.add(a3);
        alumnos.add(a4);
        alumnos.add(a5);
        alumnos.add(a6);

        Clase clase = new Clase("2DAM", alumnos);
        clase.showClase();

    }
}
