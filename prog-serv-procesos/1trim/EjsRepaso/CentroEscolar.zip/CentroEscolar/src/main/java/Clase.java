import java.util.List;
import java.util.stream.Collectors;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class Clase {
    private String nombre;
    private List<Alumno> alumnos;

    public double getMedia() {
        int suma = 0;
        for (Alumno alumno: alumnos) {
            suma+=alumno.getNota();
        }
        return (double) suma/this.alumnos.size();
    }

    public void showClase() {
        System.out.println("Clase: "+getNombre());
        System.out.println("La media de los "+alumnos.size()+" alumnos es: "+getMedia());
        System.out.println("El nombre de los alumnos analizados es: "+ showAlumnos());
        //alumnos.forEach(a -> System.out.print(a.getNombre()+));
    }

    public String showAlumnos() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < this.alumnos.size(); i++) {
            if (i < this.alumnos.size()-1) {
                sb.append(alumnos.get(i).getNombre()).append(", ");
            } else {
                sb.append(alumnos.get(i).getNombre()).append(". ");
            }
        }
        return sb.toString();
    }
}
