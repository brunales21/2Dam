import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Alumno {
    private String nombre;
    private int nota;

    public Alumno() {
        this.nombre = "Anonimo";
        this.nota = 0;
    }

    public Alumno(String nombre) {
        this.nombre = nombre;
        this.nota = 0;
    }

    public Alumno(int nota) {
        this.nombre = "Anonimo";
        this.nota = nota;
    }
}
