package ejerciciosRepaso;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.IntStream;

public class Main {
    public static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        //insertAndGet();       //ej1
        //mixer();              //ej2
        //getListaOrdenada();   //ej3
    }

    //1. Leer 5 números y mostrarlos en el mismo orden introducido
    public static void insertAndGet() {
        List<Integer> nums = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            System.out.println(i+" Introduce un entero: ");
            nums.add(sc.nextInt());
        }
        nums.forEach(n -> System.out.print(n+" "));
    }

    //2. Leer por teclado dos tablas de 10 números enteros y mezclarlas en una tercera de la
    //forma: el 1º de A, el 1º de B, el 2º de A, el 2º de B, etc
    public static void mixer() {
        List<Integer> list1 = new ArrayList<>();
        List<Integer> list2 = new ArrayList<>();
        List<Integer> targetList = new ArrayList<>();

        System.out.println("Numeros para la tabla 1");
        insertNums(list1);

        System.out.println("Numeros para la tabla 2");
        insertNums(list2);
        int maxCap = 10;

        for (int i = 0; i < maxCap; i++) {
            targetList.add(list1.get(i));
            targetList.add(list2.get(i));
        }
        System.out.print("Tabla mezclada: ");
        targetList.forEach(n -> System.out.print(n+" "));
    }

    public static void insertNums(List<Integer> list) {
        for (int i = 0; i < 10; i++) {
            System.out.print(i+" Introduce un entero: ");
            list.add(sc.nextInt());
        }
    }

    //3. Leer 5 elementos numéricos que se introducirán ordenados de forma creciente. Éstos
    //los guardaremos en un array de tamaño 10. Leer un número N, e insertarlo en el lugar
    //adecuado para que el array continúe ordenado.
    public static void getListaOrdenada() {
        int [] numeros = new int[10];
        int maxNums = 5;
        System.out.println("Introduce una secuencia de 5 numeros ordenados crecientemente.");
        for (int i = 0; i < maxNums; i++) {
            System.out.print(i+" Introduce un entero: ");
            numeros[i] = sc.nextInt();
        }
        System.out.println("Introduce otro numero y ordenare el conjunto.");
        numeros[maxNums+1] = sc.nextInt();
        Arrays.sort(numeros);
        Arrays.stream(numeros).forEach(n -> System.out.print(n+" "));
    }
}
