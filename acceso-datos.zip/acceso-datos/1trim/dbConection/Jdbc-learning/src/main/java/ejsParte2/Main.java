package ejsParte2;

import java.time.LocalDate;
import java.util.Date;

public class Main {
    public static void main(String[] args) {
        String url = "jdbc:mysql://127.0.0.1:3306/empleados";
        String username = "root";
        String password = "";
        EmpleadoDAOSql daoSql = new EmpleadoDAOSql(url, username, password);

        Empleado nuevoEmpleado = new Empleado(500, "Pepe", "Perez", "pp@scott.com", "934123456",  LocalDate.of(1997, 6, 17), "AD_PRES", 224000.00, 0.00);
        System.out.println(daoSql.insertEmpleado(nuevoEmpleado, 301, 10));

    }
}
