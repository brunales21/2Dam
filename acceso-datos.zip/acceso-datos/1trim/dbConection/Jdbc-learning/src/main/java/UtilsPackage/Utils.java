package UtilsPackage;

public class Utils {
    public static boolean esPar(int n) {
        return n % 2 == 0;
    }
}
